//
//  ViewController.swift
//  Demo_Flickr
//
//  Created by Atmakuru Ranjith Reddy on 6/6/21.
//

import UIKit
import AVFoundation

class FlickrData: NSObject {
    
    class func loadData(data : [[String:Any]]) -> [flickrModel] {
        
        var arrFlickrData : [flickrModel] = []
        
        for photoData in data {
            
            var strTitle = ""
            var imageURL = ""
            
            if let title = photoData["title"] as? String {
                strTitle = title
            }
            
            if let id = photoData["id"] as? String, let secret = photoData["secret"] as? String, let server = photoData["server"] as? String, let farm = photoData["farm"] as? Int {
                
                imageURL = "https://farm\(farm).staticflickr.com/\(server)/\(id)_\(secret).jpg"
                
                print(imageURL)
            }
            
            let model = flickrModel.init(strTitle: strTitle, imageURL: imageURL)
            arrFlickrData.append(model)
        }
        arrFlickrData.removeLast()
        
        print(arrFlickrData.count)
        return arrFlickrData
    }
    
}

struct flickrModel {
    let strTitle: String
    let imageURL: String
}



