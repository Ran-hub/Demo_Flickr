//
//  WebServices.swift
//  Demo_Flickr
//
//  Created by Atmakuru Ranjith Reddy on 6/6/21.
//

import UIKit
import AVFoundation

class WebServices: NSObject {
    
    class func fetchFlickrData(completionHandler: @escaping (([flickrModel]) -> Void)) {
        
        var arrFlickrModel :[flickrModel] = []
        
      let url = URL(string: "https://api.flickr.com/services/rest/?method=flickr.galleries.getPhotos&api_key=afc8c6820fed8c4f1797f59e59249d49&gallery_id=66911286-72157647277042064&format=json&nojsoncallback=1")!

      let task = URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
        if let error = error {
          print("Error with fetching films: \(error)")
          return
        }
        
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
                print("Error with the response, unexpected status code: \(String(describing: response))")
          return
        }
        
        if let flickrData = data {
            
            let jsonResult = try? JSONSerialization.jsonObject(with: flickrData, options: .mutableContainers)
            
            if let dictResult = jsonResult as? [String:Any], let photos = dictResult["photos"] as? [String:Any], let photo = photos["photo"] as? [[String:Any]] {
                    
                    arrFlickrModel = FlickrData.loadData(data: photo)
                    completionHandler(arrFlickrModel)
                }
        }
        
      })
      task.resume()
    }

    
}
