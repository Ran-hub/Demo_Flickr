//
//  ViewController+UICollectionView.swift
//  Demo_Flickr
//
//  Created by Atmakuru Ranjith Reddy on 6/6/21.
//

import UIKit

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrFlickrData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if (indexPath.row == self.intInsertRow) && (self.intInsertRow != -10)  {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell_FlickrDetailView", for: indexPath) as! Cell_FlickrDetailView
            
            cell.lblText.text = self.strInsertText
            
            return cell
        }
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell_Flickr", for: indexPath) as! Cell_Flickr
        
        let model = self.arrFlickrData[indexPath.row]
        let urlPhoto = URL(string: model.imageURL)
        
        cell.imgFlickr?.sd_setImage(with: urlPhoto, placeholderImage: UIImage(), options: .refreshCached, progress: nil, completed: { (urlImage, error, type, url) in
            
        })
        
        if (indexPath.row == self.intSelectedRow)  {
            cell.imgFlickr?.layer.borderWidth = 2
            cell.imgFlickr?.layer.borderColor = UIColor.blue.cgColor
            cell.imgFlickr?.clipsToBounds = true
            
            cell.imgArrow?.isHidden = false
        } else {
            cell.imgFlickr?.layer.borderWidth = 0
            
            cell.imgArrow?.isHidden = true
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if self.intSelectedRow == indexPath.row {
            
            //Remove: If selected 2nd time
            self.removeAndInsertView(isInsert:false)
            
        } else {
            
            //Remove  & Add New
            self.removeAndInsertView(isInsert: true)
            
            //Add
            let model = self.arrFlickrData[indexPath.row]
            self.strInsertText = model.strTitle
            
            if ((indexPath.row + 1) % 2 == 0) {
                self.intSelectedRow = indexPath.row
                self.intInsertRow = indexPath.row + 1
            } else {
                self.intSelectedRow = indexPath.row
                self.intInsertRow = indexPath.row + 2
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self.insertItemInCollectionView()
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if (indexPath.row == self.intInsertRow) && (self.intInsertRow != -10)  {
            
            let screenWidth = self.view.bounds.size.width-5
            let screenHeight : CGFloat = 70
            
            return CGSize(width: screenWidth, height: screenHeight)
        }
        
        let screenWidth = (self.view.bounds.size.width-10)/2
        return CGSize(width: screenWidth, height: screenWidth)
    }
    
    func insertItemInCollectionView() {

        if self.arrFlickrData.count == self.intSelectedRow + 1 {
            
            self.arrFlickrData.append(flickrModel(strTitle: "Text", imageURL: "Text"))
            
        } else {
            
            self.arrFlickrData.insert(flickrModel(strTitle: "Text", imageURL: "Text"), at: self.intInsertRow)
        }
        
        print("Array Count: \(self.arrFlickrData.count)")
        self.collFlickr.reloadData()
    }
    
    func removeAndInsertView(isInsert:Bool) {
        
        if (self.intInsertRow != -10) {
            
            self.arrFlickrData.remove(at: self.intInsertRow)
            //self.collFlickr.reloadData()
            
            self.intSelectedRow = -10
            self.intInsertRow = -10
            self.strInsertText = ""
            
            print("Array Count: \(self.arrFlickrData.count)")
            self.collFlickr.reloadData()
        }
        
//        if !isInsert {
//            //Remove
//            self.collFlickr.reloadData()
//        }
        
        
    }
    
    
}

class Cell_Flickr: UICollectionViewCell {
    
    @IBOutlet var imgFlickr: UIImageView?
    @IBOutlet var imgArrow: UIImageView?
    
}

class Cell_FlickrDetailView: UICollectionViewCell {
    
    @IBOutlet var lblText: UILabel!
    
}


