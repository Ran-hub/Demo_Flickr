//
//  ViewController.swift
//  Demo_Flickr
//
//  Created by Atmakuru Ranjith Reddy on 6/6/21.
//


import UIKit
import SDWebImage

class ViewController: UIViewController {

    //MARK:- IBOutlet
    @IBOutlet var collFlickr : UICollectionView!
    
    @IBOutlet var activityIndicator: UIActivityIndicatorView!
    
    //MARK:- Inside Class Variables
    var arrFlickrData : [flickrModel] = []
    
    var intSelectedRow = -10 //Used for selected
    var intInsertRow = -10 //Used for selected
    var strInsertText = "" //Used for selected
    
    //MARK:- UIView Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Fetch Flickr Data From API
        WebServices.fetchFlickrData { (responseData) in
            self.arrFlickrData = responseData
            
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
                self.collFlickr.reloadData()
            }
        }
        
    }
    
    

}

